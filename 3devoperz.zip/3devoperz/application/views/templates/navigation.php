<nav class="navbar navbar-dark bg-dark">
<a class="navbar-brand" href="<?php echo base_url(); ?>">
  <img src="<?php echo $app_icon; ?>" width="30" height="30" class="d-inline-block align-top" alt="">
  <?php echo $app_name; ?>
</a>
</nav>