<div class="wrapper">
    <div class="container-fluid">
        <?php echo $content; ?>
    </div>
</div>
